// product/types/product.types.ts

// ── Variant ───────────────────────────────────────────────────────────────
export interface ProductVariant {
  unit: string;
  price: number;
  quantity: number;
  sku: string;
  minOrderQuantity: number;
  bulkPrice: number;
  stockThreshold: number;
}

// ── Product Image ─────────────────────────────────────────────────────────
export interface ProductImage {
  url: string;
  publicId?: string;
  altText?: string;
}

// ── Product ───────────────────────────────────────────────────────────────
export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  category: string;
  categoryId: string;
  tags: string[];

  variants: ProductVariant[];

  images: ProductImage[];
  image: string;            // shorthand → images[0].url

  featured: boolean;
  isActive: boolean;
  isDeleted: boolean;

  discountPercentage: number;

  totalStock: number;
  inStock: boolean;
  lowStockVariants: ProductVariant[];

  rating: number;
  reviewCount: number;

  createdBy: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
}

// ── Category ──────────────────────────────────────────────────────────────
export interface Category {
  id: string;
  name: string;
  color: string;
  image: string;
}

// ── Banner ────────────────────────────────────────────────────────────────
export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  discount: string;
  backgroundColor: string;
  image: string;
}

// ── Cart ──────────────────────────────────────────────────────────────────
export interface CartItem {
  product: Product;
  selectedVariant: ProductVariant;
  quantity: number;
}