// product/services/cart.service.ts

import { API } from '../../../app/lib/api';
import type { CartItem, Product, ProductVariant } from '../types/product.types';

export interface CartResponse {
  items: CartItem[];
  count: number;
  total: number;
}

// ── Mappers ───────────────────────────────────────────────────────────────
const toVariant = (raw: any): ProductVariant => ({
  unit:             raw.unit             ?? 'pcs',
  price:            raw.price            ?? 0,
  quantity:         raw.quantity         ?? 0,
  sku:              raw.sku              ?? '',
  minOrderQuantity: raw.minOrderQuantity ?? 1,
  bulkPrice:        raw.bulkPrice        ?? 0,
  stockThreshold:   raw.stockThreshold   ?? 10,
});

const toProduct = (raw: any): Product => ({
  id:                raw._id ?? raw.id,
  name:              raw.name              ?? '',
  slug:              raw.slug              ?? '',
  description:       raw.description       ?? '',
  category:          raw.category          ?? '',
  categoryId:        raw.category          ?? '',
  tags:              raw.tags              ?? [],
  variants:          (raw.variants ?? []).map(toVariant),
  images:            raw.images            ?? [],
  image:             raw.images?.[0]?.url  ?? raw.image ?? '',
  featured:          raw.featured          ?? false,
  isActive:          raw.isActive          ?? true,
  isDeleted:         raw.isDeleted         ?? false,
  discountPercentage:raw.discountPercentage ?? 0,
  totalStock:        raw.totalStock        ?? 0,
  inStock:           raw.inStock           ?? true,
  lowStockVariants:  [],
  rating:            raw.rating            ?? 4.5,
  reviewCount:       raw.reviewCount       ?? 0,
  createdBy:         raw.createdBy         ?? '',
  createdAt:         raw.createdAt         ?? '',
  updatedAt:         raw.updatedAt         ?? '',
});

const toCartItem = (raw: any): CartItem => {
  const product = toProduct(raw.product);
  // selectedVariant: backend sends the chosen sku, match it from variants
  const selectedVariant =
    product.variants.find(v => v.sku === raw.variantSku) ??
    product.variants[0];
  return { product, selectedVariant, quantity: raw.quantity };
};

const toCartResponse = (data: any): CartResponse => ({
  items: (data.items ?? []).map(toCartItem),
  count: data.totalItems ?? 0,
  total: data.totalPrice ?? 0,
});

// ── Service ───────────────────────────────────────────────────────────────
export const cartService = {

  getCart: async (): Promise<CartResponse> => {
    const { data } = await API.get('/cart');
    return toCartResponse(data.data);
  },

  syncCart: async (
    items: { productId: string; variantSku: string; quantity: number }[],
  ): Promise<CartResponse> => {
    const { data } = await API.post('/cart/sync', { items });
    return toCartResponse(data.data);
  },

  addItem: async (
    productId: string,
    sku: string,
    quantity = 1,
  ): Promise<CartResponse> => {
    const { data } = await API.post('/cart/items', { productId, sku, quantity });
    return toCartResponse(data.data);
  },

  updateItem: async (
    productId: string,
    sku: string,
    quantity: number,
  ): Promise<CartResponse> => {
    const { data } = await API.patch(`/cart/items/${productId}`, { sku, quantity });
    return toCartResponse(data.data);
  },

  removeItem: async (
    productId: string,
    sku: string,
  ): Promise<CartResponse> => {
    const { data } = await API.delete(`/cart/items/${productId}`, {
      data: { sku },
    });
    return toCartResponse(data.data);
  },

  clearCart: async (): Promise<void> => {
    await API.delete('/cart');
  },
};