/**
 * product.store.ts
 * Zustand store — all cart mutations hit the real backend.
 * Optimistic updates keep the UI snappy; errors roll back.
 */

import { create } from 'zustand';
import type { CartItem, Product, ProductVariant } from '../types/product.types';
import { cartService, type CartResponse } from '../services/cart.service';
import { getVariantDiscountedPrice } from '../utils/product.utils';

// ─── helpers ──────────────────────────────────────────────────────────────────
function deriveCountAndTotal(items: CartItem[]) {
  return {
    cartCount: items.reduce((s, i) => s + i.quantity, 0),
    cartTotal: items.reduce(
      (s, i) =>
        s +
        getVariantDiscountedPrice(i.selectedVariant, i.product.discountPercentage) *
          i.quantity,
      0,
    ),
  };
}

function applyServerCart(res: CartResponse): Partial<ProductStore> {
  return {
    cartItems:   res.items,
    cartCount:   res.count,
    cartTotal:   res.total,
    cartLoading: false,
    cartError:   null,
  };
}

/** Unique key per cart line — same product in different units = different lines */
const lineKey = (productId: string, sku: string) => `${productId}::${sku}`;

// ─── store shape ──────────────────────────────────────────────────────────────
interface ProductStore {
  cartItems:   CartItem[];
  cartCount:   number;
  cartTotal:   number;
  cartLoading: boolean;
  cartError:   string | null;

  /** Load cart from the backend (call on app start / login). */
  fetchCart: () => Promise<void>;

  /**
   * Sync a guest cart after login.
   * Pass the local items collected while the user was unauthenticated.
   */
  syncGuestCart: (guestItems: CartItem[]) => Promise<void>;

  /** Optimistically add a variant line to cart, then confirm with backend. */
  addToCart: (product: Product, variant: ProductVariant, quantity?: number) => Promise<void>;

  /** Optimistically update quantity for a specific variant line. */
  updateQuantity: (productId: string, sku: string, quantity: number) => Promise<void>;

  /** Optimistically remove a specific variant line. */
  removeFromCart: (productId: string, sku: string) => Promise<void>;

  /** Clear entire cart (no optimistic — destructive action). */
  clearCart: () => Promise<void>;
}

// ─── store ────────────────────────────────────────────────────────────────────
export const useProductStore = create<ProductStore>((set, get) => ({
  cartItems:   [],
  cartCount:   0,
  cartTotal:   0,
  cartLoading: false,
  cartError:   null,

  // ── fetchCart ──────────────────────────────────────────────────────────────
  fetchCart: async () => {
    set({ cartLoading: true, cartError: null });
    try {
      const res = await cartService.getCart();
      set(applyServerCart(res));
    } catch (err: any) {
      set({ cartLoading: false, cartError: err.message ?? 'Failed to load cart' });
    }
  },

  // ── syncGuestCart ──────────────────────────────────────────────────────────
  syncGuestCart: async (guestItems) => {
    if (guestItems.length === 0) { await get().fetchCart(); return; }
    set({ cartLoading: true, cartError: null });
    try {
      const payload = guestItems.map(i => ({
        productId:   i.product.id,
        variantSku:  i.selectedVariant.sku,   // ← variant sku sent to backend
        quantity:    i.quantity,
      }));
      const res = await cartService.syncCart(payload);
      set(applyServerCart(res));
    } catch (err: any) {
      set({ cartLoading: false, cartError: err.message ?? 'Cart sync failed' });
    }
  },

  // ── addToCart ──────────────────────────────────────────────────────────────
  addToCart: async (product, variant, quantity = 1) => {
    const prev = get().cartItems;
    const key  = lineKey(product.id, variant.sku);

    // Optimistic — bump existing line or push a new one
    const optimistic: CartItem[] = prev.some(
      i => lineKey(i.product.id, i.selectedVariant.sku) === key,
    )
      ? prev.map(i =>
          lineKey(i.product.id, i.selectedVariant.sku) === key
            ? { ...i, quantity: i.quantity + quantity }
            : i,
        )
      : [...prev, { product, selectedVariant: variant, quantity }];

    set({ cartItems: optimistic, ...deriveCountAndTotal(optimistic) });

    try {
      const res = await cartService.addItem(product.id, variant.sku, quantity);
      set(applyServerCart(res));
    } catch (err: any) {
      set({ cartItems: prev, ...deriveCountAndTotal(prev), cartError: err.message });
    }
  },

  // ── updateQuantity ─────────────────────────────────────────────────────────
  updateQuantity: async (productId, sku, quantity) => {
    if (quantity <= 0) { await get().removeFromCart(productId, sku); return; }

    const prev = get().cartItems;
    const key  = lineKey(productId, sku);

    const optimistic = prev.map(i =>
      lineKey(i.product.id, i.selectedVariant.sku) === key ? { ...i, quantity } : i,
    );
    set({ cartItems: optimistic, ...deriveCountAndTotal(optimistic) });

    try {
      const res = await cartService.updateItem(productId, sku, quantity);
      set(applyServerCart(res));
    } catch (err: any) {
      set({ cartItems: prev, ...deriveCountAndTotal(prev), cartError: err.message });
    }
  },

  // ── removeFromCart ─────────────────────────────────────────────────────────
  removeFromCart: async (productId, sku) => {
    const prev = get().cartItems;
    const key  = lineKey(productId, sku);

    const optimistic = prev.filter(
      i => lineKey(i.product.id, i.selectedVariant.sku) !== key,
    );
    set({ cartItems: optimistic, ...deriveCountAndTotal(optimistic) });

    try {
      const res = await cartService.removeItem(productId, sku);
      set(applyServerCart(res));
    } catch (err: any) {
      set({ cartItems: prev, ...deriveCountAndTotal(prev), cartError: err.message });
    }
  },

  // ── clearCart ──────────────────────────────────────────────────────────────
  clearCart: async () => {
    set({ cartLoading: true, cartError: null });
    try {
      await cartService.clearCart();
      set({ cartItems: [], cartCount: 0, cartTotal: 0, cartLoading: false });
    } catch (err: any) {
      set({ cartLoading: false, cartError: err.message ?? 'Failed to clear cart' });
    }
  },
}));