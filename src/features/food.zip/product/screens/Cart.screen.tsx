// product/screens/Cart.screen.tsx

import React, { useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, Image, ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';

import { Colors, Typography, Radius } from '../../../theme';
import { useProductStore } from '../store/product.store';
import { useAuthStore }    from '../../auth/store/auth.store';
import { formatPrice, getVariantDiscountedPrice } from '../utils/product.utils';
import type { CartItem } from '../types/product.types';
import type { ProductStackParamList } from '../../../app/navigation/navigation.types';

type Props = NativeStackScreenProps<ProductStackParamList, 'Cart'>;

const TAB_BAR_HEIGHT = 80;

export const CartScreen: React.FC<Props> = ({ navigation }) => {
  const insets = useSafeAreaInsets();

  const cartItems    = useProductStore(s => s.cartItems);
  const cartTotal    = useProductStore(s => s.cartTotal);
  const cartLoading  = useProductStore(s => s.cartLoading);
  const cartError    = useProductStore(s => s.cartError);
  const updateQty    = useProductStore(s => s.updateQuantity);
  const removeFromCart = useProductStore(s => s.removeFromCart);
  const clearCart    = useProductStore(s => s.clearCart);

  const isLoggedIn   = useAuthStore(s => !!s.token);

  const handleCheckout = useCallback(() => {
    if (!isLoggedIn) {
      (navigation as any).navigate('Login');
      return;
    }
    (navigation as any).navigate('Orders', { screen: 'Checkout', initial: false });
  }, [isLoggedIn, navigation]);

  // ── Empty state ─────────────────────────────────────────────────────────
  if (!cartLoading && cartItems.length === 0) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <View style={styles.topBar}>
          <TouchableOpacity style={styles.topBtn} onPress={() => navigation.goBack()}>
            <Text style={styles.topBtnText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.topTitle}>My Cart</Text>
          <View style={{ width: 40 }} />
        </View>

        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>🛒</Text>
          <Text style={styles.emptyTitle}>Your cart is empty</Text>
          <Text style={styles.emptySubtitle}>Add some products to get started</Text>
          <TouchableOpacity
            style={styles.shopBtn}
            onPress={() => navigation.goBack()}
            activeOpacity={0.85}
          >
            <Text style={styles.shopBtnText}>Continue Shopping</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ── Cart item row ────────────────────────────────────────────────────────
  const renderItem = ({ item }: { item: CartItem }) => {
    const { product, selectedVariant, quantity } = item;
    const linePrice = getVariantDiscountedPrice(selectedVariant, product.discountPercentage);
    const lineTotal = linePrice * quantity;

    return (
      <View style={styles.itemCard}>
        <Image
          source={{ uri: product.image }}
          style={styles.itemImage}
          resizeMode="cover"
        />

        <View style={styles.itemInfo}>
          <Text style={styles.itemName} numberOfLines={2}>{product.name}</Text>

          {/* Variant badge */}
          <View style={styles.variantBadge}>
            <Text style={styles.variantBadgeText}>
              {selectedVariant.unit.toUpperCase()}
            </Text>
            {selectedVariant.sku ? (
              <Text style={styles.variantSkuText}> · {selectedVariant.sku}</Text>
            ) : null}
          </View>

          {/* Price + original if discounted */}
          <View style={styles.itemPriceRow}>
            <Text style={styles.itemPrice}>{formatPrice(linePrice)}</Text>
            {product.discountPercentage > 0 && (
              <Text style={styles.itemOriginalPrice}>
                {formatPrice(selectedVariant.price)}
              </Text>
            )}
            <Text style={styles.itemUnit}>/{selectedVariant.unit}</Text>
          </View>

          <View style={styles.itemBottom}>
            {/* Qty controls */}
            <View style={styles.qtyRow}>
              <TouchableOpacity
                style={styles.qtyBtn}
                onPress={() => {
                  if (quantity - 1 <= 0) {
                    removeFromCart(product.id, selectedVariant.sku);
                  } else {
                    updateQty(product.id, selectedVariant.sku, quantity - 1);
                  }
                }}
              >
                <Text style={styles.qtyBtnText}>−</Text>
              </TouchableOpacity>
              <Text style={styles.qtyVal}>{quantity}</Text>
              <TouchableOpacity
                style={[styles.qtyBtn, styles.qtyBtnPlus]}
                onPress={() =>
                  updateQty(product.id, selectedVariant.sku, quantity + 1)
                }
              >
                <Text style={[styles.qtyBtnText, { color: Colors.white }]}>+</Text>
              </TouchableOpacity>
            </View>

            {/* Line total */}
            <Text style={styles.lineTotal}>{formatPrice(lineTotal)}</Text>
          </View>
        </View>

        {/* Remove button */}
        <TouchableOpacity
          style={styles.removeBtn}
          onPress={() => removeFromCart(product.id, selectedVariant.sku)}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Text style={styles.removeBtnText}>✕</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {/* ── Top Bar ─────────────────────────────────────────────────────── */}
      <View style={styles.topBar}>
        <TouchableOpacity style={styles.topBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.topBtnText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.topTitle}>My Cart ({cartItems.length})</Text>
        {cartItems.length > 0 ? (
          <TouchableOpacity onPress={clearCart} style={styles.clearBtn}>
            <Text style={styles.clearBtnText}>Clear</Text>
          </TouchableOpacity>
        ) : (
          <View style={{ width: 40 }} />
        )}
      </View>

      {/* ── Error banner ────────────────────────────────────────────────── */}
      {cartError ? (
        <View style={styles.errorBanner}>
          <Text style={styles.errorBannerText}>⚠️ {cartError}</Text>
        </View>
      ) : null}

      {/* ── Cart list ───────────────────────────────────────────────────── */}
      {cartLoading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={Colors.primary} />
        </View>
      ) : (
        <FlatList
          data={cartItems}
          keyExtractor={i => `${i.product.id}::${i.selectedVariant.sku}`}
          renderItem={renderItem}
          contentContainerStyle={{
            padding: 16,
            paddingBottom: TAB_BAR_HEIGHT + insets.bottom + 100,
            gap: 12,
          }}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* ── Summary bar ─────────────────────────────────────────────────── */}
      {!cartLoading && cartItems.length > 0 && (
        <View style={[styles.summaryBar, { paddingBottom: Math.max(insets.bottom, 16) }]}>
          {/* Items breakdown */}
          <View style={styles.summaryRows}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>
                Subtotal ({cartItems.reduce((s, i) => s + i.quantity, 0)} items)
              </Text>
              <Text style={styles.summaryValue}>{formatPrice(cartTotal)}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Delivery</Text>
              <Text style={[styles.summaryValue, { color: Colors.primary }]}>FREE</Text>
            </View>
            <View style={[styles.summaryRow, styles.summaryTotalRow]}>
              <Text style={styles.summaryTotalLabel}>Total</Text>
              <Text style={styles.summaryTotalValue}>{formatPrice(cartTotal)}</Text>
            </View>
          </View>

          <TouchableOpacity
            style={styles.checkoutBtn}
            onPress={handleCheckout}
            activeOpacity={0.88}
          >
            <Text style={styles.checkoutBtnText}>
              Proceed to Checkout ⚡
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe:    { flex: 1, backgroundColor: Colors.background },
  centered:{ flex: 1, alignItems: 'center', justifyContent: 'center' },

  // ── Top bar ───────────────────────────────────────────────────────────────
  topBar: {
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 12,
    backgroundColor: Colors.background,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  topBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: Colors.white,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08, shadowRadius: 6, elevation: 3,
  },
  topBtnText: {
    fontSize: 20, lineHeight: 20,
    includeFontPadding: false,
    color: Colors.textPrimary,
  },
  topTitle:    { ...Typography.titleLarge, color: Colors.textPrimary },
  clearBtn:    { paddingHorizontal: 10, paddingVertical: 6 },
  clearBtnText:{ ...Typography.bodySmall, color: Colors.error, fontWeight: '600' },

  // ── Error banner ──────────────────────────────────────────────────────────
  errorBanner: {
    backgroundColor: '#FFF0F0',
    paddingVertical: 10, paddingHorizontal: 20,
    borderBottomWidth: 1, borderBottomColor: '#FFD0D0',
  },
  errorBannerText: { ...Typography.bodySmall, color: Colors.error },

  // ── Empty state ───────────────────────────────────────────────────────────
  emptyState: {
    flex: 1, alignItems: 'center', justifyContent: 'center', paddingBottom: 80, gap: 8,
  },
  emptyIcon:    { fontSize: 72, marginBottom: 8 },
  emptyTitle:   { ...Typography.headingMedium, color: Colors.textPrimary },
  emptySubtitle:{ ...Typography.bodyMedium, color: Colors.textSecondary },
  shopBtn: {
    marginTop: 16, backgroundColor: Colors.primary,
    paddingHorizontal: 28, paddingVertical: 14,
    borderRadius: Radius.full,
  },
  shopBtnText: { ...Typography.labelLarge, color: Colors.white },

  // ── Item card ─────────────────────────────────────────────────────────────
  itemCard: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    borderRadius: Radius.lg,
    padding: 12,
    gap: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05, shadowRadius: 4, elevation: 2,
  },
  itemImage: {
    width: 88, height: 88,
    borderRadius: Radius.md,
    backgroundColor: Colors.grey100,
  },
  itemInfo:  { flex: 1, gap: 4 },
  itemName:  { ...Typography.bodyMedium, color: Colors.textPrimary, fontWeight: '700' },

  // Variant badge
  variantBadge: {
    flexDirection: 'row', alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: Colors.primary + '15',
    borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 3,
  },
  variantBadgeText: { ...Typography.bodySmall, color: Colors.primary, fontWeight: '700' },
  variantSkuText:   { ...Typography.bodySmall, color: Colors.primary + 'AA' },

  // Price
  itemPriceRow:    { flexDirection: 'row', alignItems: 'baseline', gap: 4 },
  itemPrice:       { ...Typography.bodyMedium, color: Colors.textPrimary, fontWeight: '700' },
  itemOriginalPrice: { ...Typography.bodySmall, color: Colors.textDisabled, textDecorationLine: 'line-through' },
  itemUnit:        { ...Typography.bodySmall, color: Colors.textSecondary },

  // Bottom row: qty + total
  itemBottom:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 },
  qtyRow:      { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: Colors.grey100, borderRadius: Radius.full, paddingHorizontal: 4, paddingVertical: 3 },
  qtyBtn:      { width: 28, height: 28, borderRadius: 14, backgroundColor: Colors.white, alignItems: 'center', justifyContent: 'center' },
  qtyBtnPlus:  { backgroundColor: Colors.primary },
  qtyBtnText:  { fontSize: 16, color: Colors.textPrimary, fontWeight: '700', lineHeight: 20 },
  qtyVal:      { ...Typography.bodyMedium, color: Colors.textPrimary, fontWeight: '700', minWidth: 20, textAlign: 'center' },
  lineTotal:   { ...Typography.bodyMedium, color: Colors.primary, fontWeight: '800' },

  // Remove button
  removeBtn:     { position: 'absolute', top: 10, right: 10, padding: 4 },
  removeBtnText: { fontSize: 13, color: Colors.textDisabled, fontWeight: '700' },

  // ── Summary bar ───────────────────────────────────────────────────────────
  summaryBar: {
    backgroundColor: Colors.white,
    paddingHorizontal: 24, paddingTop: 16,
    borderTopWidth: 1, borderTopColor: Colors.border,
    shadowColor: '#000', shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.06, shadowRadius: 8,
    elevation: 10000, zIndex: 10000,
  },
  summaryRows:      { gap: 8, marginBottom: 14 },
  summaryRow:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  summaryTotalRow:  { borderTopWidth: 1, borderTopColor: Colors.border, paddingTop: 10, marginTop: 2 },
  summaryLabel:     { ...Typography.bodyMedium, color: Colors.textSecondary },
  summaryValue:     { ...Typography.bodyMedium, color: Colors.textPrimary, fontWeight: '700' },
  summaryTotalLabel:{ ...Typography.titleMedium, color: Colors.textPrimary, fontWeight: '800' },
  summaryTotalValue:{ ...Typography.titleLarge, color: Colors.textPrimary, fontWeight: '800' },
  checkoutBtn: {
    backgroundColor: Colors.primary,
    paddingVertical: 14, borderRadius: Radius.full,
    alignItems: 'center',
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.35, shadowRadius: 8, elevation: 6,
  },
  checkoutBtnText: { ...Typography.labelLarge, color: Colors.white },
});