/**
 * features/product/screens/ProductDetail.screen.tsx
 *
 * Fixed:
 *  1. Uses app theme colors (Colors from theme/color.ts — primary is #FF6B35 orange)
 *  2. Add to Cart → calls useProductStore.addToCart (real backend via cart.service)
 *  3. Buy Now → navigates to Checkout inside OrderNavigator
 *  4. No bottom tab bar shown (HIDDEN_ON_ROUTES in MainNavigator already hides it,
 *     but we also add 'ProductDetail' to that set via tabBarStyle in screenOptions)
 *  5. Floating back/heart/share nav sits correctly over the image using SafeAreaView
 *  6. Zero emojis — all icons from lucide-react-native
 *  7. API envelope unwrapped: response is { success, data: Product }
 *  8. Uses API from app/lib/api (axios) — not the old api.service fetch wrapper
 */

import React, { useState, useCallback, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  Image, StatusBar, FlatList, ActivityIndicator,
  Dimensions, Platform, Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation }    from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import {
  ArrowLeft, Heart, Share2, Star,
  ShoppingCart, Zap,
  Truck, ShieldCheck, RotateCcw, Headphones,
  Leaf, Package, Layers, Weight,
  AlertTriangle, CheckCircle, XCircle, Award, Tag,
} from 'lucide-react-native';

import { Colors }            from '../../../theme/color';
import { API }               from '../../../app/lib/api';
import { useProductStore }   from '../store/product.store';
import type { Product, ProductVariant } from '../types/product.types';
import type { ProductStackParamList }   from '../navigation.types';

// ─── Navigation type ──────────────────────────────────────────────────────────
type Nav = NativeStackNavigationProp<ProductStackParamList, 'ProductDetail'>;

// ─── Layout constants ─────────────────────────────────────────────────────────
const W            = Dimensions.get('window').width;
const IMAGE_HEIGHT = 320;

// ─── Trust badges ─────────────────────────────────────────────────────────────
const TRUST = [
  { key: 'delivery', title: 'Fast Delivery', sub: 'Same Day'    },
  { key: 'secure',   title: 'Secure',        sub: 'Payments'    },
  { key: 'returns',  title: 'Easy',          sub: 'Returns'     },
  { key: 'support',  title: '24/7',          sub: 'Support'     },
];

// ─── Icon helpers (zero emojis) ───────────────────────────────────────────────
function TrustIcon({ k }: { k: string }) {
  const p = { size: 22, color: Colors.primary, strokeWidth: 1.7 };
  if (k === 'delivery') return <Truck       {...p} />;
  if (k === 'secure')   return <ShieldCheck {...p} />;
  if (k === 'returns')  return <RotateCcw   {...p} />;
  return <Headphones {...p} />;
}

function UnitIcon({ unit, color }: { unit: string; color: string }) {
  const p = { size: 17, color, strokeWidth: 1.9 };
  const u = (unit ?? '').toLowerCase();
  if (u.includes('kg') || u.includes('g'))  return <Weight {...p} />;
  if (u.includes('l') || u.includes('ml'))  return <Layers {...p} />;
  return <Package {...p} />;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
const fmt = (n: number) =>
  `₹${Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;

const calcDiscounted = (price: number, pct: number) =>
  Math.round(price * (1 - pct / 100) * 100) / 100;

// ─── API — unwrap envelope ────────────────────────────────────────────────────
const fetchProduct = async (id: string): Promise<Product> => {
  const { data: res } = await API.get<{ success: boolean; data: Product }>(`/products/${id}`);
  return res.data;
};

// ─── VariantRow ───────────────────────────────────────────────────────────────
interface VariantRowProps {
  variant:     ProductVariant;
  selected:    boolean;
  discountPct: number;
  onSelect:    () => void;
}

const VariantRow: React.FC<VariantRowProps> = ({ variant, selected, discountPct, onSelect }) => {
  const price      = calcDiscounted(variant.price, discountPct);
  const isLow      = variant.quantity <= variant.stockThreshold;
  const iconColor  = selected ? Colors.primary : Colors.grey500;

  return (
    <TouchableOpacity
      style={[s.varRow, selected && s.varRowSel]}
      onPress={onSelect}
      activeOpacity={0.82}
    >
      {/* Radio */}
      <View style={[s.radio, selected && s.radioSel]}>
        {selected && <View style={s.radioDot} />}
      </View>

      {/* Icon box */}
      <View style={[s.varIconBox, selected && s.varIconBoxSel]}>
        <UnitIcon unit={variant.unit} color={iconColor} />
      </View>

      {/* Labels */}
      <View style={s.varInfo}>
        <Text style={[s.varLabel, selected && s.varLabelSel]}>
          {variant.unit.toUpperCase()}
        </Text>
        <Text style={s.varMin}>Min order: {variant.minOrderQuantity} {variant.unit}</Text>
        {variant.bulkPrice > 0 && (
          <Text style={s.varBulk}>
            Bulk: {fmt(variant.bulkPrice)}/{variant.unit}
          </Text>
        )}
      </View>

      {/* Price + Stock */}
      <View style={s.varRight}>
        <Text style={[s.varPrice, selected && s.varPriceSel]}>
          {fmt(price)}
          <Text style={s.varUnit}> /{variant.unit}</Text>
        </Text>
        {isLow ? (
          <View style={s.lowRow}>
            <AlertTriangle size={10} color={Colors.warning} />
            <Text style={s.lowTxt}>{variant.quantity} left</Text>
          </View>
        ) : (
          <Text style={s.varStockTxt}>Stock: {variant.quantity}</Text>
        )}
      </View>
    </TouchableOpacity>
  );
};

// ─── Main Screen ──────────────────────────────────────────────────────────────
interface Props {
  route?: { params?: { productId?: string } };
}

export const ProductDetailScreen: React.FC<Props> = ({ route }) => {
  const navigation  = useNavigation<Nav>();
  const insets      = useSafeAreaInsets();
  const productId   = route?.params?.productId;

  // Store actions
  const addToCart   = useProductStore(s => s.addToCart);
  const fetchCart   = useProductStore(s => s.fetchCart);
  const cartLoading = useProductStore(s => s.cartLoading);

  // Local state
  const [product, setProduct]       = useState<Product | null>(null);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState<string | null>(null);
  const [activeImg, setActiveImg]   = useState(0);
  const [selVariant, setSelVariant] = useState<ProductVariant | null>(null);
  const [qty, setQty]               = useState(1);
  const [wishlisted, setWishlisted] = useState(false);
  const [addingCart, setAddingCart] = useState(false);

  // ── Sync cart from backend on mount ─────────────────────────────────────────
  useEffect(() => { fetchCart(); }, []);

  // ── Fetch ────────────────────────────────────────────────────────────────────
  const load = useCallback(() => {
    if (!productId) { setError('No product ID'); setLoading(false); return; }
    let cancelled = false;
    setLoading(true);
    setError(null);
    fetchProduct(productId)
      .then(p => {
        if (cancelled) return;
        setProduct(p);
        const def = p.variants?.find(v => v.quantity > 0) ?? p.variants?.[0] ?? null;
        setSelVariant(def);
      })
      .catch(e => { if (!cancelled) setError(e?.message ?? 'Failed to load'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [productId]);

  useEffect(() => { const unsub = load(); return unsub; }, [load]);

  // ── Derived prices ───────────────────────────────────────────────────────────
  const basePrice = product && selVariant
    ? calcDiscounted(selVariant.price, product.discountPercentage) : 0;

  const effectivePrice =
    selVariant && selVariant.bulkPrice > 0 && qty >= selVariant.minOrderQuantity
      ? selVariant.bulkPrice
      : basePrice;

  const totalPrice = effectivePrice * qty;
  const maxQty     = selVariant?.quantity ?? 99;

  // ── Add to Cart ──────────────────────────────────────────────────────────────
  const handleAddToCart = useCallback(async () => {
    if (!product || !selVariant) return;
    setAddingCart(true);
    try {
      await addToCart(product, selVariant, qty);
      Alert.alert('Added to Cart', `${product.name} (${selVariant.unit} × ${qty}) added.`);
    } catch {
      Alert.alert('Error', 'Could not add to cart. Please try again.');
    } finally {
      setAddingCart(false);
    }
  }, [product, selVariant, qty, addToCart]);

  // ── Buy Now ──────────────────────────────────────────────────────────────────
  const handleBuyNow = useCallback(async () => {
    if (!product || !selVariant) return;
    // Add to cart first then go to checkout (cart-based checkout flow)
    setAddingCart(true);
    try {
      await addToCart(product, selVariant, qty);
    } finally {
      setAddingCart(false);
    }
    // Navigate to Checkout — it reads from cartItems in the store
    (navigation as any).navigate('Orders', { screen: 'Checkout' });
  }, [navigation, product, selVariant, qty, addToCart]);

  // ── Loading ──────────────────────────────────────────────────────────────────
  if (loading) return (
    <View style={s.center}>
      <ActivityIndicator size="large" color={Colors.primary} />
      <Text style={s.loadTxt}>Loading…</Text>
    </View>
  );

  // ── Error ────────────────────────────────────────────────────────────────────
  if (error || !product) return (
    <View style={s.center}>
      <XCircle size={44} color={Colors.error} />
      <Text style={s.errTxt}>{error ?? 'Product not found'}</Text>
      <TouchableOpacity style={s.retryBtn} onPress={load}>
        <Text style={s.retryTxt}>Retry</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={[s.retryBtn, { backgroundColor: Colors.grey200, marginTop: 8 }]}
        onPress={() => navigation.goBack()}
      >
        <Text style={[s.retryTxt, { color: Colors.textPrimary }]}>Go Back</Text>
      </TouchableOpacity>
    </View>
  );

  const images  = product.images  ?? [];
  const tags    = product.tags    ?? [];
  const inStock = product.inStock;
  const busy    = addingCart || cartLoading;

  // ── Render ───────────────────────────────────────────────────────────────────
  return (
    <View style={s.root}>
      {/* Transparent status bar so image bleeds under it */}
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        bounces
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        {/* ── Hero image — full bleed, no corner radius ── */}
        <View style={s.imgWrap}>
          {images.length > 0 ? (
            <FlatList
              data={images}
              keyExtractor={(_, i) => String(i)}
              horizontal pagingEnabled
              showsHorizontalScrollIndicator={false}
              scrollEnabled={images.length > 1}
              onMomentumScrollEnd={e =>
                setActiveImg(Math.round(e.nativeEvent.contentOffset.x / W))
              }
              renderItem={({ item }) => (
                <Image
                  source={{ uri: item.url }}
                  style={s.heroImg}
                  resizeMode="cover"
                  accessibilityLabel={item.altText || product.name}
                />
              )}
            />
          ) : (
            // Fallback grey box when no images
            <View style={[s.heroImg, { backgroundColor: Colors.grey200, alignItems: 'center', justifyContent: 'center' }]}>
              <Package size={64} color={Colors.grey400} />
            </View>
          )}

          {/* ── Floating nav — back + heart + share ── */}
          {/* Use padding from insets so it clears status bar on both iOS & Android */}
          <View
            style={[
              s.floatNav,
              { paddingTop: insets.top + (Platform.OS === 'android' ? 6 : 4) },
            ]}
            pointerEvents="box-none"
          >
            <TouchableOpacity
              style={s.floatBtn}
              onPress={() => navigation.goBack()}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              <ArrowLeft size={20} color={Colors.white} strokeWidth={2.2} />
            </TouchableOpacity>

            <View style={s.floatRight}>
              <TouchableOpacity style={s.floatBtn} onPress={() => setWishlisted(w => !w)}>
                <Heart
                  size={19} strokeWidth={2}
                  color={Colors.white}
                  fill={wishlisted ? Colors.white : 'none'}
                />
              </TouchableOpacity>
              <TouchableOpacity style={s.floatBtn}>
                <Share2 size={19} color={Colors.white} strokeWidth={2} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Featured badge */}
          {product.featured && (
            <View style={[s.featuredBadge, { top: insets.top + (Platform.OS === 'android' ? 54 : 52) }]}>
              <Award size={12} color={Colors.warning} strokeWidth={2} />
              <Text style={s.featuredTxt}>Featured</Text>
            </View>
          )}

          {/* Pagination */}
          {images.length > 1 && (
            <View style={s.pageBadge}>
              <Text style={s.pageTxt}>{activeImg + 1}/{images.length}</Text>
            </View>
          )}
        </View>

        {/* ── Content card — no top radius, flushes with image ── */}
        <View style={s.card}>

          {/* Title + discount */}
          <View style={s.titleRow}>
            <Text style={s.name} numberOfLines={2}>{product.name}</Text>
            {product.discountPercentage > 0 && (
              <View style={s.discBadge}>
                <Text style={s.discTxt}>-{product.discountPercentage}%</Text>
              </View>
            )}
          </View>

          {/* Category + rating + stock */}
          <View style={s.metaRow}>
            <View style={s.catPill}>
              <Tag size={10} color={Colors.textSecondary} strokeWidth={2} />
              <Text style={s.catTxt}>{product.category}</Text>
            </View>

            {product.rating > 0 && (
              <View style={s.starRow}>
                <Star size={13} color={Colors.warning} fill={Colors.warning} />
                <Text style={s.starVal}>{product.rating}</Text>
                {product.reviewCount > 0 && (
                  <Text style={s.starCount}>({product.reviewCount})</Text>
                )}
              </View>
            )}

            <View style={[s.stockBadge, inStock ? s.inStockBg : s.outStockBg]}>
              {inStock
                ? <CheckCircle size={11} color={Colors.success}  strokeWidth={2.5} />
                : <XCircle     size={11} color={Colors.error}    strokeWidth={2.5} />
              }
              <Text style={[s.stockTxt, inStock ? s.inStockClr : s.outStockClr]}>
                {inStock ? 'In Stock' : 'Out of Stock'}
              </Text>
            </View>
          </View>

          {/* Description */}
          {!!product.description && (
            <Text style={s.desc}>{product.description}</Text>
          )}

          {/* Tags */}
          {tags.length > 0 && (
            <View style={s.tagsRow}>
              {tags.map(tag => (
                <View key={tag} style={s.tagChip}>
                  <Leaf size={10} color={Colors.grey500} strokeWidth={2} />
                  <Text style={s.tagTxt}>{tag}</Text>
                </View>
              ))}
            </View>
          )}

          <View style={s.divider} />

          {/* Variants */}
          <Text style={s.sectionTitle}>Select Variant</Text>
          {product.variants.map((v, i) => (
            <VariantRow
              key={v.sku || i}
              variant={v}
              selected={selVariant?.sku === v.sku}
              discountPct={product.discountPercentage}
              onSelect={() => { setSelVariant(v); setQty(1); }}
            />
          ))}

          <View style={s.divider} />

          {/* Quantity + Total */}
          <View style={s.qtySection}>
            <View>
              <Text style={s.sectionTitle}>Quantity</Text>
              <View style={s.qtyRow}>
                <TouchableOpacity
                  style={s.qtyBtn}
                  onPress={() => setQty(q => Math.max(1, q - 1))}
                >
                  <Text style={s.qtyBtnTxt}>−</Text>
                </TouchableOpacity>
                <Text style={s.qtyVal}>{qty}</Text>
                <TouchableOpacity
                  style={[s.qtyBtn, qty >= maxQty && s.qtyBtnOff]}
                  onPress={() => setQty(q => Math.min(maxQty, q + 1))}
                  disabled={qty >= maxQty}
                >
                  <Text style={s.qtyBtnTxt}>+</Text>
                </TouchableOpacity>
              </View>
              {selVariant && selVariant.bulkPrice > 0 && qty < selVariant.minOrderQuantity && (
                <Text style={s.bulkHint}>
                  Order {selVariant.minOrderQuantity}+ for {fmt(selVariant.bulkPrice)}/{selVariant.unit}
                </Text>
              )}
            </View>

            <View style={s.totalBlock}>
              <Text style={s.totalLabel}>Total</Text>
              <Text style={s.totalPrice}>{fmt(totalPrice)}</Text>
              {effectivePrice !== basePrice && (
                <Text style={s.bulkApplied}>Bulk price applied</Text>
              )}
            </View>
          </View>

          {/* CTA buttons */}
          <View style={s.ctaRow}>
            <TouchableOpacity
              style={[s.cartBtn, (!inStock || busy) && s.btnOff]}
              onPress={handleAddToCart}
              disabled={!inStock || busy}
              activeOpacity={0.85}
            >
              {busy
                ? <ActivityIndicator size="small" color={Colors.white} />
                : <ShoppingCart size={18} color={Colors.white} strokeWidth={2} />
              }
              <Text style={s.cartTxt}>Add to Cart</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[s.buyBtn, (!inStock || busy) && s.btnOff]}
              onPress={handleBuyNow}
              disabled={!inStock || busy}
              activeOpacity={0.85}
            >
              {busy
                ? <ActivityIndicator size="small" color={Colors.primary} />
                : <Zap size={18} color={Colors.primary} strokeWidth={2} fill={Colors.primary} />
              }
              <Text style={s.buyTxt}>Buy Now</Text>
            </TouchableOpacity>
          </View>

          {/* Trust badges */}
          <View style={s.trustRow}>
            {TRUST.map(b => (
              <View key={b.key} style={s.trustItem}>
                <TrustIcon k={b.key} />
                <Text style={s.trustTitle}>{b.title}</Text>
                <Text style={s.trustSub}>{b.sub}</Text>
              </View>
            ))}
          </View>

        </View>
      </ScrollView>
    </View>
  );
};

// ─── Styles ───────────────────────────────────────────────────────────────────
const Radius = { sm: 6, md: 10, lg: 14, xl: 20 };

const s = StyleSheet.create({
  root:    { flex: 1, backgroundColor: Colors.background },
  center:  { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, backgroundColor: Colors.surface, padding: 24 },
  loadTxt: { color: Colors.textSecondary, marginTop: 8, fontSize: 14 },
  errTxt:  { color: Colors.error, fontSize: 15, marginTop: 8, textAlign: 'center' },
  retryBtn:{ marginTop: 4, paddingHorizontal: 24, paddingVertical: 12, backgroundColor: Colors.primary, borderRadius: Radius.md },
  retryTxt:{ color: Colors.white, fontWeight: '700', fontSize: 14 },

  // Image
  imgWrap: { width: W, height: IMAGE_HEIGHT, backgroundColor: Colors.black },
  heroImg: { width: W, height: IMAGE_HEIGHT },

  // Floating nav — absolutely positioned over the image
  floatNav: {
    position: 'absolute', top: 0, left: 0, right: 0, zIndex: 20,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 14,
  },
  floatRight: { flexDirection: 'row', gap: 8 },
  floatBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: 'rgba(0,0,0,0.38)',
    alignItems: 'center', justifyContent: 'center',
  },

  // Featured
  featuredBadge: {
    position: 'absolute', left: 14, zIndex: 10,
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.white, borderRadius: Radius.xl,
    paddingHorizontal: 10, paddingVertical: 5,
    shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4, elevation: 3,
  },
  featuredTxt: { fontSize: 12, fontWeight: '700', color: Colors.textPrimary },

  // Pagination
  pageBadge: {
    position: 'absolute', bottom: 14, right: 14,
    backgroundColor: 'rgba(0,0,0,0.48)',
    borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4,
  },
  pageTxt: { color: Colors.white, fontSize: 12, fontWeight: '600' },

  // Card — NO top radius, flush with image
  card: { backgroundColor: Colors.surface, padding: 20 },

  // Title
  titleRow:  { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 },
  name:      { fontSize: 22, fontWeight: '700', color: Colors.textPrimary, flex: 1, marginRight: 10, lineHeight: 28 },
  discBadge: { backgroundColor: '#FEF2F2', borderRadius: Radius.md, paddingHorizontal: 10, paddingVertical: 4 },
  discTxt:   { color: Colors.error, fontWeight: '700', fontSize: 13 },

  // Meta
  metaRow:    { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12, flexWrap: 'wrap' },
  catPill:    { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.grey100, borderRadius: Radius.xl, paddingHorizontal: 10, paddingVertical: 4 },
  catTxt:     { fontSize: 11, color: Colors.textSecondary, fontWeight: '500', textTransform: 'capitalize' },
  starRow:    { flexDirection: 'row', alignItems: 'center', gap: 3 },
  starVal:    { fontWeight: '700', fontSize: 13, color: Colors.textPrimary },
  starCount:  { fontSize: 12, color: Colors.textSecondary },
  stockBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, borderRadius: Radius.sm, paddingHorizontal: 8, paddingVertical: 3 },
  inStockBg:  { backgroundColor: '#DCFCE7' },
  outStockBg: { backgroundColor: '#FEF2F2' },
  stockTxt:   { fontWeight: '600', fontSize: 11 },
  inStockClr: { color: Colors.success },
  outStockClr:{ color: Colors.error },

  // Desc
  desc: { fontSize: 13, color: Colors.textSecondary, lineHeight: 20, marginBottom: 14 },

  // Tags
  tagsRow: { flexDirection: 'row', gap: 8, flexWrap: 'wrap', marginBottom: 12 },
  tagChip: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.grey100, borderRadius: Radius.xl, paddingHorizontal: 9, paddingVertical: 4 },
  tagTxt:  { fontSize: 11, color: Colors.textPrimary, fontWeight: '500' },

  divider: { height: 1, backgroundColor: Colors.border, marginVertical: 16 },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: Colors.textPrimary, marginBottom: 12 },

  // Variant row
  varRow: {
    flexDirection: 'row', alignItems: 'center',
    borderWidth: 1.5, borderColor: Colors.border,
    borderRadius: Radius.lg, padding: 12, marginBottom: 10, gap: 10,
  },
  varRowSel:     { borderColor: Colors.primary, backgroundColor: Colors.white },
  radio:         { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: Colors.grey300, alignItems: 'center', justifyContent: 'center' },
  radioSel:      { borderColor: Colors.primary },
  radioDot:      { width: 10, height: 10, borderRadius: 5, backgroundColor: Colors.primary },
  varIconBox:    { width: 36, height: 36, borderRadius: 8, backgroundColor: Colors.grey100, alignItems: 'center', justifyContent: 'center' },
  varIconBoxSel: { backgroundColor: Colors.primary + '22' },
  varInfo:       { flex: 1 },
  varLabel:      { fontSize: 14, fontWeight: '600', color: Colors.textPrimary },
  varLabelSel:   { color: Colors.textPrimary },
  varMin:        { fontSize: 11, color: Colors.textSecondary, marginTop: 1 },
  varBulk:       { fontSize: 10, color: Colors.primary, marginTop: 2, fontWeight: '500' },
  varRight:      { alignItems: 'flex-end' },
  varPrice:      { fontSize: 14, fontWeight: '700', color: Colors.textPrimary },
  varPriceSel:   { color: Colors.primary },
  varUnit:       { fontSize: 12, fontWeight: '400', color: Colors.textSecondary },
  varStockTxt:   { fontSize: 11, color: Colors.success, marginTop: 2, fontWeight: '500' },
  lowRow:        { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 2 },
  lowTxt:        { fontSize: 11, color: Colors.warning, fontWeight: '600' },

  // Qty
  qtySection: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  qtyRow:     { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
  qtyBtn:     { width: 36, height: 36, borderRadius: 8, borderWidth: 1, borderColor: Colors.border, alignItems: 'center', justifyContent: 'center', backgroundColor: Colors.white },
  qtyBtnOff:  { opacity: 0.35 },
  qtyBtnTxt:  { fontSize: 20, color: Colors.textPrimary, lineHeight: 24 },
  qtyVal:     { minWidth: 48, textAlign: 'center', fontSize: 16, fontWeight: '700', color: Colors.textPrimary },
  bulkHint:   { fontSize: 10, color: Colors.primary, marginTop: 4, fontWeight: '500' },
  totalBlock: { alignItems: 'flex-end' },
  totalLabel: { fontSize: 13, color: Colors.textSecondary },
  totalPrice: { fontSize: 22, fontWeight: '800', color: Colors.primary, marginTop: 2 },
  bulkApplied:{ fontSize: 10, color: Colors.success, fontWeight: '600', marginTop: 2 },

  // CTA
  ctaRow: { flexDirection: 'row', gap: 12, marginBottom: 20 },
  cartBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, backgroundColor: Colors.primary, borderRadius: Radius.lg, paddingVertical: 15,
    shadowColor: Colors.primary, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3, shadowRadius: 8, elevation: 6,
  },
  cartTxt: { color: Colors.white, fontWeight: '700', fontSize: 15 },
  buyBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, borderWidth: 1.5, borderColor: Colors.primary,
    borderRadius: Radius.lg, paddingVertical: 15, backgroundColor: Colors.white,
  },
  buyTxt:  { color: Colors.primary, fontWeight: '700', fontSize: 15 },
  btnOff:  { opacity: 0.45 },

  // Trust
  trustRow:   { flexDirection: 'row', justifyContent: 'space-between', borderWidth: 1, borderColor: Colors.border, borderRadius: Radius.lg, paddingVertical: 14, paddingHorizontal: 6 },
  trustItem:  { alignItems: 'center', flex: 1, gap: 4 },
  trustTitle: { fontSize: 11, fontWeight: '700', color: Colors.textPrimary, textAlign: 'center' },
  trustSub:   { fontSize: 10, color: Colors.textSecondary, textAlign: 'center' },
});

export default ProductDetailScreen;