/**
 * order.service.ts
 * Wraps all /api/orders endpoints.
 *
 * Backend routes consumed:
 *   POST   /api/orders              → placeOrder
 *   GET    /api/orders              → getOrderHistory  (paginated)
 *   GET    /api/orders/:id          → getOrderById
 *   PATCH  /api/orders/:id/cancel   → cancelOrder
 *   PATCH  /api/orders/:id/status   → updateStatus     (admin only)
 */

import { API } from '../../../app/lib/api';
import type {
  Order,
  OrderItem,
  OrderListResult,
  OrderPagination,
  PlaceOrderPayload,
} from '../types/order.types';

// ─── Backend raw shapes ───────────────────────────────────────────────────────

interface BackendOrderProduct {
  _id?:   string;
  id?:    string;
  name:   string;
  image?: string;
  price:  number;
  unit?:  string;
}

interface BackendOrderItem {
  product:  BackendOrderProduct;
  quantity: number;
  price:    number;
}

interface BackendOrder {
  _id:             string;
  id?:             string;
  status:          string;
  items:           BackendOrderItem[];
  subtotal?:       number;
  shippingFee?:    number;
  discount?:       number;
  total:           number;
  deliveryAddress: {
    fullName:    string;
    phone:       string;
    street:      string;
    city:        string;
    state?:      string;
    postalCode?: string;
  };
  promoCode?: string;
  createdAt:  string;
  updatedAt:  string;
}

interface BackendPagination {
  total?:       number;
  totalOrders?: number;
  page?:        number;
  limit?:       number;
  totalPages?:  number;
}

// ─── Normalisers ──────────────────────────────────────────────────────────────

const toOrderItem = (raw: BackendOrderItem): OrderItem => ({
  product: {
    id:    raw.product._id ?? raw.product.id ?? '',
    name:  raw.product.name,
    image: raw.product.image ?? '',
    price: raw.product.price,
    unit:  raw.product.unit  ?? 'pcs',
  },
  quantity: raw.quantity,
  price:    raw.price,
});

const toOrder = (raw: BackendOrder): Order => ({
  id:          raw._id ?? raw.id ?? '',
  status:      raw.status as Order['status'],
  items:       (raw.items ?? []).map(toOrderItem),
  subtotal:    raw.subtotal    ?? 0,
  shippingFee: raw.shippingFee ?? 0,
  discount:    raw.discount    ?? 0,
  totalAmount:       raw.total,
  deliveryAddress: {
    fullName:   raw.deliveryAddress?.fullName   ?? '',
    phone:      raw.deliveryAddress?.phone      ?? '',
    street:     raw.deliveryAddress?.street     ?? '',
    city:       raw.deliveryAddress?.city       ?? '',
    state:      raw.deliveryAddress?.state,
    postalCode: raw.deliveryAddress?.postalCode,
  },
  promoCode: raw.promoCode,
  createdAt:  raw.createdAt,
  updatedAt:  raw.updatedAt,
});

const toPagination = (
  raw: BackendPagination,
  page: number,
  limit: number,
): OrderPagination => ({
  total:      raw.total ?? raw.totalOrders ?? 0,
  page:       raw.page  ?? page,
  limit:      raw.limit ?? limit,
  totalPages: raw.totalPages ?? 1,
});

// ─── List params ──────────────────────────────────────────────────────────────

export interface OrderHistoryParams {
  page?:   number;
  limit?:  number;
  status?: string;
}

// ─── Service ──────────────────────────────────────────────────────────────────

export const orderService = {

  /**
   * POST /api/orders
   * Places a new order from the user's current cart.
   */
  placeOrder: async (payload: PlaceOrderPayload): Promise<Order> => {
    const { data } = await API.post('/orders', payload);
    return toOrder(data?.data ?? data);
  },

  /**
   * GET /api/orders
   * Returns paginated order history for the logged-in user.
   */
  getOrderHistory: async (params: OrderHistoryParams = {}): Promise<OrderListResult> => {
    const page  = params.page  ?? 1;
    const limit = params.limit ?? 10;

    const query: Record<string, any> = { page, limit };
    if (params.status) query.status = params.status;

    const { data } = await API.get('/orders', { params: query });
    const raw = data?.data ?? data;

    const orders: BackendOrder[] = raw.orders ?? raw.data ?? [];
    const pagination = toPagination(raw.pagination ?? raw, page, limit);

    return { orders: orders.map(toOrder), pagination };
  },

  /**
   * GET /api/orders/:id
   * Fetches a single order (user's own or admin).
   */
  getOrderById: async (orderId: string): Promise<Order> => {
    const { data } = await API.get(`/orders/${orderId}`);
    return toOrder(data?.data ?? data);
  },

  /**
   * PATCH /api/orders/:id/cancel
   * Cancels a pending order.
   */
  cancelOrder: async (orderId: string): Promise<Order> => {
    const { data } = await API.patch(`/orders/${orderId}/cancel`, {});
    return toOrder(data?.data ?? data);
  },
};