/**
 * Checkout.screen.tsx
 *
 * Two flows:
 *   • Guest (no token)  → Sign-in / Register wall; cart is preserved
 *   • Logged in         → form prefilled from auth profile; editable before submit
 *
 * On success → clears cart → navigates to OrderSuccess
 */

import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, StatusBar, ActivityIndicator,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { Colors, Typography, Radius } from '../../../theme';
import { useProductStore } from '../../product/store/product.store';
import { useAuthStore }    from '../../auth/store/auth.store';
import { useOrderStore }   from '../store/order.store';
import { formatOrderPrice } from '../utils/order.utils';
import type { DeliveryAddress } from '../types/order.types';
import type { OrderStackParamList } from '../navigation.types';

type Nav = NativeStackNavigationProp<OrderStackParamList, 'Checkout'>;

const SHIPPING = 30;

// ─── Reusable field ───────────────────────────────────────────────────────────

interface FieldProps {
  label:         string;
  value:         string;
  onChange:      (v: string) => void;
  placeholder?:  string;
  keyboardType?: 'default' | 'phone-pad';
  required?:     boolean;
}

const Field: React.FC<FieldProps> = ({
  label, value, onChange, placeholder, keyboardType = 'default', required,
}) => (
  <View style={fieldStyles.wrap}>
    <Text style={fieldStyles.label}>
      {label}
      {required && <Text style={fieldStyles.required}> *</Text>}
    </Text>
    <TextInput
      style={fieldStyles.input}
      value={value}
      onChangeText={onChange}
      placeholder={placeholder ?? label}
      placeholderTextColor={Colors.textDisabled}
      keyboardType={keyboardType}
      autoCapitalize={keyboardType === 'phone-pad' ? 'none' : 'words'}
    />
  </View>
);

const fieldStyles = StyleSheet.create({
  wrap:     { gap: 6 },
  label:    {
    ...Typography.bodySmall, color: Colors.textSecondary,
    fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.6,
  },
  required: { color: Colors.error },
  input:    {
    height: 50, borderRadius: Radius.md,
    borderWidth: 1.5, borderColor: Colors.border,
    paddingHorizontal: 14,
    ...Typography.bodyMedium, color: Colors.textPrimary,
    backgroundColor: Colors.white,
  },
});

// ─── Screen ───────────────────────────────────────────────────────────────────

export const CheckoutScreen: React.FC = () => {
  const navigation = useNavigation<Nav>();
  const insets     = useSafeAreaInsets();

  // product store
  const cartItems  = useProductStore(s => s.cartItems);
  const cartTotal  = useProductStore(s => s.cartTotal);
  const clearCart  = useProductStore(s => s.clearCart);

  // auth
  const isLoggedIn = useAuthStore(s => !!s.token);
  const profile    = useAuthStore(s => s.user);

  // order store
  const placeOrder = useOrderStore(s => s.placeOrder);
  const isPlacing  = useOrderStore(s => s.isPlacing);
  const placeError = useOrderStore(s => s.placeError);
  const clearErrors = useOrderStore(s => s.clearErrors);

  const total = cartTotal + SHIPPING;

  // ── Form state ──────────────────────────────────────────────────────────────
  const [fullName,   setFullName]   = useState('');
  const [phone,      setPhone]      = useState('');
  const [street,     setStreet]     = useState('');
  const [city,       setCity]       = useState('');
  const [state,      setStateName]  = useState('');
  const [postalCode, setPostalCode] = useState('');

  const [validationError, setValidationError] = useState<string | null>(null);

  // ── Prefill from auth profile ───────────────────────────────────────────────
  useEffect(() => {
    if (!profile) return;
    setFullName(profile.name  ?? '');
    setPhone(profile.phone    ?? '');
    if (profile.addresses && profile.addresses.length > 0) {
      const addr =
        profile.addresses.find(a => a.label === 'home') ?? profile.addresses[0];
      setStreet(addr.street         ?? '');
      setCity(addr.city             ?? '');
      setStateName(addr.state       ?? '');
      setPostalCode(addr.postalCode ?? '');
    }
  }, [profile]);

  // Clear store errors when leaving
  useEffect(() => () => { clearErrors(); }, []);

  // ── Validate ────────────────────────────────────────────────────────────────
  const validate = (): boolean => {
    if (!fullName.trim()) { setValidationError('Full name is required.'); return false; }
    if (!phone.trim())    { setValidationError('Phone number is required.'); return false; }
    if (!street.trim())   { setValidationError('Street address is required.'); return false; }
    if (!city.trim())     { setValidationError('City is required.'); return false; }
    return true;
  };

  // ── Submit ──────────────────────────────────────────────────────────────────
  const handlePlaceOrder = async () => {
    setValidationError(null);
    if (!validate()) return;

    const deliveryAddress: DeliveryAddress = {
      fullName:   fullName.trim(),
      phone:      phone.trim(),
      street:     street.trim(),
      city:       city.trim(),
      state:      state.trim()      || undefined,
      postalCode: postalCode.trim() || undefined,
    };

    const order = await placeOrder({ deliveryAddress });
    if (order) {
      await clearCart();
      navigation.replace('OrderSuccess', { orderId: order.id });
    }
  };

  const displayError = validationError ?? placeError;

  // ── Guest wall ──────────────────────────────────────────────────────────────
  if (!isLoggedIn) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <StatusBar barStyle="dark-content" backgroundColor={Colors.background} />
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Text style={styles.backIcon}>‹</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Checkout</Text>
          <View style={{ width: 36 }} />
        </View>

        <View style={styles.guestWall}>
          <Text style={styles.guestEmoji}>🔐</Text>
          <Text style={styles.guestTitle}>Sign in to continue</Text>
          <Text style={styles.guestSubtitle}>
            Create an account or log in to place your order.{'\n'}Your cart is saved.
          </Text>
          <TouchableOpacity
            style={styles.primaryBtn}
            onPress={() => (navigation as any).navigate('Login')}
          >
            <Text style={styles.primaryBtnText}>Sign In</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.outlineBtn}
            onPress={() => (navigation as any).navigate('Register')}
          >
            <Text style={styles.outlineBtnText}>Create Account</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ── Checkout form ────────────────────────────────────────────────────────────
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="dark-content" backgroundColor={Colors.background} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backIcon}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Checkout</Text>
        <View style={{ width: 36 }} />
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingBottom: insets.bottom + 120 }]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Error */}
          {displayError ? (
            <View style={styles.errorBanner}>
              <Text style={styles.errorText}>⚠️  {displayError}</Text>
            </View>
          ) : null}

          {/* ── Delivery section ── */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Delivery Details</Text>
            <View style={styles.card}>
              <Field label="Full Name"   value={fullName}   onChange={setFullName}   placeholder="John Doe"           required />
              <Field label="Phone"       value={phone}      onChange={setPhone}       placeholder="+1 555 000 0000"    keyboardType="phone-pad" required />
              <Field label="Street"      value={street}     onChange={setStreet}      placeholder="123 Main Street"    required />
              <Field label="City"        value={city}       onChange={setCity}        placeholder="New York"           required />
              <Field label="State"       value={state}      onChange={setStateName}   placeholder="NY" />
              <Field label="Postal Code" value={postalCode} onChange={setPostalCode}  placeholder="10001"              keyboardType="phone-pad" />
            </View>
          </View>

          {/* ── Order summary ── */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Order Summary</Text>
            <View style={styles.card}>
              {cartItems.map(({ product, quantity }) => (
                <View key={product.id} style={styles.summaryRow}>
                  <Text style={styles.summaryName} numberOfLines={1}>
                    {product.name}
                    <Text style={styles.summaryQty}> × {quantity}</Text>
                  </Text>
                  <Text style={styles.summaryPrice}>
                    {formatOrderPrice(product.price * quantity)}
                  </Text>
                </View>
              ))}

              <View style={styles.divider} />

              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Subtotal</Text>
                <Text style={styles.summaryValue}>{formatOrderPrice(cartTotal)}</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Shipping Fee</Text>
                <Text style={styles.summaryValue}>{formatOrderPrice(SHIPPING)}</Text>
              </View>

              <View style={styles.divider} />

              <View style={styles.summaryRow}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalValue}>{formatOrderPrice(total)}</Text>
              </View>
            </View>
          </View>
        </ScrollView>

        {/* Sticky footer */}
        <View style={[styles.footer, { paddingBottom: insets.bottom + 12 }]}>
          <TouchableOpacity
            style={[styles.placeBtn, isPlacing && { opacity: 0.6 }]}
            onPress={handlePlaceOrder}
            disabled={isPlacing}
            activeOpacity={0.88}
          >
            {isPlacing
              ? <ActivityIndicator color={Colors.white} />
              : <Text style={styles.placeBtnText}>Place Order — {formatOrderPrice(total)}</Text>
            }
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe:   { flex: 1, backgroundColor: Colors.background },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 16, gap: 20 },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 14,
    backgroundColor: Colors.white,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  backBtn:     { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  backIcon:    { fontSize: 30, color: Colors.textPrimary, lineHeight: 34 },
  headerTitle: { ...Typography.headingMedium, color: Colors.textPrimary },

  errorBanner: {
    backgroundColor: '#FFF3CD', borderRadius: Radius.md,
    paddingHorizontal: 14, paddingVertical: 10,
    borderWidth: 1, borderColor: '#FFEEBA',
  },
  errorText: { ...Typography.bodySmall, color: '#856404' },

  section:      { gap: 10 },
  sectionTitle: { ...Typography.titleMedium, color: Colors.textPrimary, fontWeight: '700' },
  card: {
    backgroundColor: Colors.white, borderRadius: Radius.lg, padding: 16, gap: 14,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 8, elevation: 3,
  },

  summaryRow:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  summaryName:  { ...Typography.bodyMedium, color: Colors.textPrimary, flex: 1, marginRight: 8 },
  summaryQty:   { color: Colors.textSecondary },
  summaryPrice: { ...Typography.bodyMedium, color: Colors.textPrimary, fontWeight: '600' },
  summaryLabel: { ...Typography.bodyMedium, color: Colors.textSecondary },
  summaryValue: { ...Typography.bodyMedium, color: Colors.textPrimary, fontWeight: '600' },
  totalLabel:   { ...Typography.titleLarge, color: Colors.textPrimary },
  totalValue:   { ...Typography.headingMedium, color: Colors.textPrimary, fontWeight: '800' },
  divider:      { height: 1, backgroundColor: Colors.border },

  footer: {
    backgroundColor: Colors.white, paddingHorizontal: 20, paddingTop: 14,
    borderTopWidth: 1, borderTopColor: Colors.border,
  },
  placeBtn: {
    height: 54, borderRadius: Radius.full, backgroundColor: Colors.primary,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: Colors.primary, shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4, shadowRadius: 12, elevation: 8,
  },
  placeBtnText: { ...Typography.labelLarge, color: Colors.white, fontSize: 16 },

  // guest wall
  guestWall: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 32, gap: 14,
  },
  guestEmoji:    { fontSize: 72 },
  guestTitle:    { ...Typography.headingMedium, color: Colors.textPrimary, textAlign: 'center' },
  guestSubtitle: { ...Typography.bodyMedium, color: Colors.textSecondary, textAlign: 'center', lineHeight: 22 },
  primaryBtn: {
    width: '100%', height: 52, borderRadius: Radius.full,
    backgroundColor: Colors.primary, alignItems: 'center', justifyContent: 'center',
    marginTop: 8,
    shadowColor: Colors.primary, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35, shadowRadius: 10, elevation: 6,
  },
  primaryBtnText: { ...Typography.labelLarge, color: Colors.white },
  outlineBtn: {
    width: '100%', height: 52, borderRadius: Radius.full,
    backgroundColor: Colors.white, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: Colors.primary,
  },
  outlineBtnText: { ...Typography.labelLarge, color: Colors.primary },
});