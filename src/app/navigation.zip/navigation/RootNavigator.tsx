/**
 * RootNavigator.tsx
 *
 * Entry point mounted in App.tsx inside <NavigationContainer>.
 *
 * Responsibilities:
 *   1. Wait for auth hydration (AsyncStorage token read)
 *   2. Show a loading indicator while hydrating
 *   3. Hand off to AppNavigator (which handles both authed + unauthed states)
 *
 * Auth gating is handled at the tab level inside MainNavigator —
 * unauthenticated users see LoginPromptScreen for Cart / Orders / Account
 * but can still browse Home and Favourite freely.
 *
 * DELETED: AuthNavigator — Login / Register / ForgotPassword screens
 * are now registered directly in AppNavigator and accessible from anywhere.
 */

import React           from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { useAuthStore } from '../../features/auth/store/auth.store';
import { AppNavigator } from './AppNavigator';
import { Colors }       from '../../theme';

export const RootNavigator: React.FC = () => {
  const loading = useAuthStore(s => s.loading);

  if (loading) {
    return (
      <View style={styles.splash}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return <AppNavigator />;
};

const styles = StyleSheet.create({
  splash: {
    flex:            1,
    alignItems:      'center',
    justifyContent:  'center',
    backgroundColor: Colors.background,
  },
});